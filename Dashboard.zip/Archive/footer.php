
		
		<div class="weatherbar row">
		
			<div class="weather_observation col-xs-6">
				<div style="position: absolute; font-size: 6vh; font-weight: bold; color: #333333; right: 10px; bottom: 1vh;">Présentement</div>
				<img src="weather/clear.png" id="forecast_icon" height="100%" style=" position: absolute; bottom: 1px; left: 10px; -webkit-filter: invert(100%)" />
				<div id="observation_weather" style="position: absolute; bottom: 5vh; left: 20vh; font-size: 5vh;">?</div>
				<div id="observation_temperature" style="position: absolute; bottom: 5vh; right: 10px; font-size: 4vh;">?</div>
				<div id="observation_feelslike" style="position: absolute; bottom: 5px; right: 10px; font-size: 3vh;">?</div>
			</div>
			<div class="weather_forecast col-xs-6" id="weather_today">
			<div id="forecast_title" style="position: absolute; font-size: 6vh; font-weight: bold; color: #333333; right: 5px; bottom: 1vh;">?</div>
				<img src="weather/nt_clear.png" id="forecast_icon" height="100%" style=" position: absolute; bottom: 1px; left: 10px; -webkit-filter: invert(100%)" />
				<div id="forecast_conditions" style="position: absolute; bottom: 5vh; left: 20vh; font-size: 5vh;">?</div>
				<div id="forecast_high" style="position: absolute; bottom: 5vh; right: 10px; font-size: 4vh;">?</div>
				<div id="forecast_low" style="position: absolute; bottom: 5px; right: 10px; font-size: 3vh;">?</div>
			</div>
			<div class="weather_forecast col-xs-6" id="weather_tomorrow" style="display: none;">
				<div id="forecast_title" style="position: absolute; font-size: 6vh; font-weight: bold; color: #333333; right: 5px; bottom: 1vh;">?</div>
				<img src="weather/nt_clear.png" id="forecast_icon" height="100%" style=" position: absolute; bottom: 1px; left: 10px; -webkit-filter: invert(100%)" />
				<div id="forecast_conditions" style="position: absolute; bottom: 5vh; left: 20vh; font-size: 5vh;">?</div>
				<div id="forecast_high" style="position: absolute; bottom: 5vh; right: 10px; font-size: 4vh;">?</div>
				<div id="forecast_low" style="position: absolute; bottom: 5px; right: 10px; font-size: 3vh;">?</div>
			</div>
		</div>
		
		<!-- End of weather section -->
	
	</body>
</html>
